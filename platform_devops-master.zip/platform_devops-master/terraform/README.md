# Terraform Usage steps

1. clone the platform_devops repo (git clone git@dev-github.albertsons.com:albertsons/platform_devops.git)
2. change directory to terraform (cd platform_devops/terraform/VM/environments/dev)
3. update the subnet where you want to create the VM (line 11)
4. Need to provide azure credentials tenant id, access key etc.
5. terraform plan, if plan is good then go ahead and apply the terraform

