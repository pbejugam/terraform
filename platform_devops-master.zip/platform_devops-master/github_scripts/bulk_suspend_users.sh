#!/bin/sh

filename=$1
while IFS=, read -r name

do

     ghe-user-suspend ${name}

done < ${filename}
