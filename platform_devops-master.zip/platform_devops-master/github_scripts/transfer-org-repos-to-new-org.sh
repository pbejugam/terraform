#!/bin/bash
################################################################################
################################################################################
####### Transfer Org Repos to New Org @AdmiralAwkbar ###########################
################################################################################
################################################################################

# LEGEND:
# This script will use the GitHub API to gather a list of
# all repositories in a GitHub.com Organization, and transfer
# them to a new Organization
#
# PREREQS:
# You will need a GitHub Personal Access token to query the api
# You will need jq installed on the system
#
# HOW To Run:
# - Copy file to local machine
# - chmod +x file.sh
# - ./file.sh
# - pass the file input that is requested
#

PrintUsage()
{
  cat <<EOM
Usage: transfer-org-repos-to-new-org [options]

Options:
  -h, --help              : Print this message
  -d, --debug             : Enable debug logging
  -u, --url               : Set GHE URL (e.g. https://github.example.com) - Defaults to github.com if omitted
  -t, --token             : Set Personal Access Token with repo scope - Looks for GITHUB_TOKEN environment 
                            variable, then prompts if omitted
  -S, --source-org        : Source Organization to scan and migrate repositories - prompts for name if omitted
  -D, --destination-org   : Destination Organization for migrating repositories - prompts for name if omitted

Description:
  transfer-org-repos-to-new-org transfers all repositories from one organization to another

Example:
  ./transfer-org-repos-to-new-org.sh -u https://github.example.com -t ABCDEFG1234567 -S old_org -D new-org

EOM
  exit 0
}

####################################
# Read in the parameters if passed #
####################################
PARAMS=""
while (( "$#" )); do
  case "$1" in
    -h|--help)
      PrintUsage;
      ;;
    -u|--url)
      GHE_URL=$2
      shift 2
      ;;
    -d|--DEBUG)
      DEBUG=1
      shift
      ;;
    -t|--token)
      GITHUB_PAT=$2
      shift 2
      ;;
    -S|--source-org)
      ORIG_ORG_NAME=$2
      shift 2
      ;;
    -D|--destination-org)
      NEW_ORG_NAME=$2
      shift 2
      ;;
    --) # end argument parsing
      shift
      break
      ;;
    -*) # unsupported flags
      echo "Error: Unsupported flag $1" >&2
      exit 1
      ;;
    *) # preserve positional arguments
      PARAMS="$PARAMS $1"
      shift
      ;;
  esac
done

##################################################
# Set positional arguments in their proper place #
##################################################
eval set -- "$PARAMS"

###########
# GLOBALS #
###########
REPO_ARRAY=()                       # Array of Repos to migrate
PAGE_SIZE=100                       # Size of page to return from API
SET_ORG_INFO=0                      # Flag to set high level info
TOTAL_REPOS=0                       # Count of all repos found
SUCCESSFUL_TRANSFER=0               # Count of repos that were transfered
END_CURSOR='null'                   # Default value for the end cursor on API for repos

################################################################################
############################ FUNCTIONS #########################################
################################################################################
################################################################################
#### Function PrintUsage #######################################################


#### Function Header ###########################################################
Header()
{
  echo ""
  echo "######################################################"
  echo "######################################################"
  echo "###### GitHub Transfer Org Repos to New Org ##########"
  echo "######################################################"
  echo "######################################################"
  echo ""

  ###########################################################
  # Get the Org name we will transfer all repositories from #
  ###########################################################
  if [[ -z "${ORIG_ORG_NAME}" ]]; then
    echo ""
    echo "------------------------------------------------------"
    echo "Please provide the name of the GitHub.com Organization"
    echo "that contains all repositories to be transfered, followed by [ENTER]:"
    ########################
    # Read input from user #
    ########################
    read -r ORIG_ORG_NAME

    ############################################
    # Clean any whitespace that may be entered #
    ############################################
    ORIG_ORG_NAME_NO_WHITESPACE="$(echo -e "${ORIG_ORG_NAME}" | tr -d '[:space:]')"
    ORIG_ORG_NAME=$ORIG_ORG_NAME_NO_WHITESPACE
  fi

  ###########################################################
  # Get the Org name we will transfer all repositories into #
  ###########################################################
  if [[ -z "${NEW_ORG_NAME}" ]]; then
    echo ""
    echo "------------------------------------------------------"
    echo "Please provide the name of the GitHub.com Organization"
    echo "that all repositories will be transfered into, followed by [ENTER]:"
    ########################
    # Read input from user #
    ########################
    read -r NEW_ORG_NAME

    ############################################
    # Clean any whitespace that may be entered #
    ############################################
    NEW_ORG_NAME_NO_WHITESPACE="$(echo -e "${NEW_ORG_NAME}" | tr -d '[:space:]')"
    NEW_ORG_NAME=$NEW_ORG_NAME_NO_WHITESPACE
  fi

  ########################################
  # Get the GitHub Personal Access Token #
  ########################################
  if [[ -z "${GITHUB_PAT}" ]]; then
    echo ""
    echo "------------------------------------------------------"
    echo "Please enter the GitHub.com Personal Access Token used to migrate"
    echo "these repositories, followed by [ENTER]:"
    echo "(note: your input will NOT be displayed)"
    ########################
    # Read input from user #
    ########################
    read -r -s GITHUB_PAT
  fi

  ##########################################
  # Check the length of the PAT for sanity #
  ##########################################
  if [ ${#GITHUB_PAT} -ne 40 ]; then
    echo "GitHub PAT's are 40 characters in length! you gave me ${#GITHUB_PAT} characters!"
    if [ $DEBUG -eq 1 ]; then
      echo "DEBUG --- PAT:[$GITHUB_PAT]"
    fi
    exit 1
  fi

  ################
  # Set the URLS #
  ################
  if [[ -z "${GHE_URL}" ]]; then
    GITHUB_URL="https://api.github.com"
    GRAPHQL_URL="https://api.github.com/graphql"
  else
    GITHUB_URL+="$GHE_URL/api/v3"
    GRAPHQL_URL="$GHE_URL/api/graphql"
  fi


  #########################
  # Prints for GitHub.com #
  #########################
  echo ""
  echo "------------------------------------------------------"
  echo "This script will use the GitHub API to connect to:[$GITHUB_URL]"
  echo "and transfer all repositories from Organization:[$ORIG_ORG_NAME] to Organization:[$NEW_ORG_NAME]."
  echo ""
  echo "------------------------------------------------------"
  echo ""
}
################################################################################
#### Function Footer ###########################################################
Footer()
{
  #######################################
  # Basic footer information and totals #
  #######################################
  echo ""
  echo "######################################################"
  echo "The script has completed"
  echo "Total Repos Parsed:[$TOTAL_REPOS]"
  echo "Total repos Successfully Migrated:[$SUCCESSFUL_TRANSFER]"
  echo "######################################################"
  echo ""
  echo ""
}
################################################################################
#### Function GetRepoData ######################################################
GetRepoData()
{
  # This step takes in the GitHub Organization name and queries
  # the GitHub APIv4 To gain information about that org, and the repos

  ###########
  # Headers #
  ###########
  echo "------------------------------------------------------"
  echo "Gathering repos from:[$ORIG_ORG_NAME]"

  #####################################
  # Update orgname string with quotes #
  #####################################
  # Needs to be quoted to allow special chars
  O_STRING='\"'
  O_STRING+="$ORIG_ORG_NAME"
  O_STRING+='\"'

  #####################################
  # Update the end_cursor if not null #
  #####################################
  # Needs to be quoted if not null
  END_CURSOR_STRING=$END_CURSOR
  if [[ "$END_CURSOR" != "null" ]]; then
    END_CURSOR_STRING='\"'
    END_CURSOR_STRING+="$END_CURSOR"
    END_CURSOR_STRING+='\"'
  fi

  ###############################
  # Call GitHub API to get info #
  ###############################
  # Note: Using the members field and not the memberswithRole field as users may not have that yet
  # This will need to be updated in the future
  DATA_BLOCK=$(curl -s -k -X POST -H "authorization: Bearer $GITHUB_PAT" -H "content-type: application/json" \
  --data '{"query":"query {\n  organization(login: '"$O_STRING"') {\n    repositories(first: '"$PAGE_SIZE"', after: '"$END_CURSOR_STRING"') {\n nodes {\n name \n }\n totalCount\n pageInfo {\n hasNextPage\n endCursor\n }\n}\n }\n}"}' \
  "$GRAPHQL_URL" 2>&1)

  #######################
  # Load the error code #
  #######################
  ERROR_CODE=$?

  ##########################
  # Check the shell return #
  ##########################
  if [ $ERROR_CODE -ne 0 ]; then
    echo "ERROR! Failed to gather data from GitHub!"
    echo "RETURN FROM COMMAND:[$DATA_BLOCK]"
    exit 1
  fi

  #########################
  # DEBUG show data block #
  #########################
  if [[ $DEBUG -eq 1 ]]; then
    echo "DEBUG --- DATA BLOCK:[$DATA_BLOCK]"
  fi

  ##########################
  # Get the Next Page Flag #
  ##########################
  NEXT_PAGE=$(echo "$DATA_BLOCK" | jq .[] | jq -r '.organization.repositories.pageInfo.hasNextPage')
  if [[ $DEBUG -eq 1 ]]; then
    echo "DEBUG --- Next Page:[$NEXT_PAGE]"
  fi

  ##############################
  # Get the Current End Cursor #
  ##############################
  END_CURSOR=$(echo "$DATA_BLOCK" | jq .[] | jq -r '.organization.repositories.pageInfo.endCursor')
  if [[ $DEBUG -eq 1 ]]; then
    echo "DEBUG --- End Cursor:[$END_CURSOR]"
  fi

  ##########################
  # Set the Org Level Info #
  ##########################
  if [ $SET_ORG_INFO -ne 1 ]; then
    #######################
    # Get the Total Repos #
    #######################
    TOTAL_REPOS=$(echo "$DATA_BLOCK" | jq .[] | jq -r '.organization.repositories.totalCount')
    ###############
    # Debug print #
    ###############
    if [[ $DEBUG -eq 1 ]]; then
      echo "DEBUG --- Total Repos Count:[$TOTAL_REPOS]"
    fi
    ################
    # Set the flag #
    ################
    SET_ORG_INFO=1
  fi

  #############################################
  # Parse all the repo data out of data block #
  #############################################
  ParseRepoData "$DATA_BLOCK"

  ########################################
  # See if we need to loop for more data #
  ########################################
  if [ "$NEXT_PAGE" == "false" ]; then
    # We have all the data, we can move on
    echo "Gathered all data from GitHub"
  elif [ "$NEXT_PAGE" == "true" ]; then
    # We need to loop through GitHub to get all repos
    echo "More pages of repos... Looping through data with new cursor:[$END_CURSOR]"
    ##########################################
    # Call GetRepoData again with new cursor #
    ##########################################
    GetRepoData
  else
    # Failing to get this value means we didnt get a good response back from GitHub
    # And it could be bad input from user, not enough access, or a bad token
    # Fail out and have user validate the info
    echo ""
    echo "######################################################"
    echo "ERROR! Failed response back from GitHub!"
    echo "Please validate your PAT, Organization, and access levels!"
    echo "######################################################"
    exit 1
  fi
}
################################################################################
#### Function ParseRepoData ####################################################
ParseRepoData()
{
  ##########################
  # Pull in the data block #
  ##########################
  PARSE_DATA=$1

  ####################################
  # Itterate through the json object #
  ####################################
  # We need to get the sizes of the repos as well
  echo "Gathering Repositories and sizes to results file..."
  for OBJECT in $(echo "$PARSE_DATA"  | jq -r '.data.organization.repositories.nodes | .[] | .name' ); do
    # Print the Repo Name
    echo "Adding Repository:[$OBJECT] to transfer list"
    #################
    # Push to array #
    #################
    REPO_ARRAY+=("$OBJECT")
  done
}
################################################################################
#### Function TransferRepos ####################################################
TransferRepos()
{
  ########################
  # Ask user to validate #
  ########################
  echo ""
  echo "------------------------------------------------------"
  echo "Are you certain you want to transfer repositories listed"
  echo "from:[$ORIG_ORG_NAME] to:[$NEW_ORG_NAME]?"
  echo "(y)es (n)o, followed by [ENTER]:"
  ########################
  # Read input from user #
  ########################
  read -r SAFETY_FLAG

  ########################
  # Check the user input #
  ########################
  if [[ "$SAFETY_FLAG" == "yes" ]] || [[ "$SAFETY_FLAG" == "y" ]]; then
    echo "You asked for it... I shall deliver... transfering the repositories..."
    ################################
    # Migrating all repos in array #
    ################################
    for REPO_NAME in "${REPO_ARRAY[@]}"
    do
      ###########################
      # Create the transfer URL #
      ###########################
      TRANSFER_URL="$GITHUB_URL/repos/$ORIG_ORG_NAME/$REPO_NAME/transfer"

      ######################
      # Call the end point #
      ######################
      TRANSFER_CMD=$(curl -s -k -X POST -H 'content-type: application/json' \
      -H 'accept: application/vnd.github.nightshade-preview+json' -H "authorization: Bearer $GITHUB_PAT" \
      --data "{ \"new_owner\": \"$NEW_ORG_NAME\"}" \
      "$TRANSFER_URL" 2>&1)

      #######################
      # Load the error code #
      #######################
      ERROR_CODE=$?

      ##########################
      # Check the shell return #
      ##########################
      if [ $ERROR_CODE -ne 0 ]; then
        echo "ERROR! Failed to transfer:[$ORIG_ORG_NAME/$REPO_NAME] to:[$NEW_ORG_NAME/$REPO_NAME]"
        echo "RETURN FROM COMMAND:[$TRANSFER_CMD]"
        exit 1
      else
        echo "Successfully Migrated:[$ORIG_ORG_NAME/$REPO_NAME] to:[$NEW_ORG_NAME/$REPO_NAME]"
        # Increment success counter
        ((SUCCESSFUL_TRANSFER++))
      fi

    done
  else
    ####################################
    # User has cancelled the migration #
    ####################################
    echo ""
    echo "------------------------------------------------------"
    echo "User has cancelled the migration process, exiting now"
    exit 1
  fi
  ################################
  # Parse through array of Repos #
  ################################
}
################################################################################
#### Function ValidateJQ #######################################################
ValidateJQ()
{
  # Need to validate the machine has jq installed as we use it to do the parsing
  # of all the json returns from GitHub

  #############################
  # See if it is in the path #
  ############################
  CHECK_JQ=$(which jq)

  #######################
  # Load the error code #
  #######################
  ERROR_CODE=$?

  ##########################
  # Check the shell return #
  ##########################
  if [ $ERROR_CODE -ne 0 ]; then
    echo "Failed to find jq in the path!"
    echo "ERROR:[$CHECK_JQ]"
    echo "If this is a Mac, run command: brew install jq"
    echo "If this is Debian, run command: sudo apt install jq"
    echo "If this is Centos, run command: yum install jq"
    echo "Once installed, please run this script again."
    exit 1
  fi
}
################################################################################
############################## MAIN ############################################
################################################################################

##########
# Header #
##########
Header

#########################
# Validate JQ installed #
#########################
ValidateJQ

########################
# Get GitHub Repo Data #
########################
GetRepoData

#########################
# Transfer Repositories #
#########################
TransferRepos

##########
# Footer #
##########
Footer
