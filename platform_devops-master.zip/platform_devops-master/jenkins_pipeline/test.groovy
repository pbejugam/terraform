import jenkins.model.Jenkins
import hudson.model.Item
import hudson.model.Items

def createJob(jobName,git_repo,location) {
  
pipelineJob(jobName) {
    definition {
        cpsScm {
            scm {
                git{
                    remote{  
                      url('git_repo')
                      credentials('dev-github')
                    }
                    branch ('master')
                }
             }
            scriptPath(location)
            lightweight(lightweight = true)
            }
        }
    }
}
    def main() {

  createJob(jobName,git_repo,location)
}

// Start execution
main()
