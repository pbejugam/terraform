job(auto-discover-pipelines) {
    description('Imports pipelines from Git, found in infra/jenkins/ from protected branches.')
    parameters {
        stringParam("Job_name", "deploy_uat", "Name of the your project job")
        stringParam("git_repo", "abc","Name of the github repo name")
        stringParam("Jenkins_file_path","all", "Please specify the location of the Jenkins file")            
    }
    scm {
        git {
            remote {
                name('origin')
                url('https://dev-github.albertsons.com/albertsons/platform_devops.git')
                credentials('dev-github')
            }
            branch('*/master')
        }
    }
    steps {
        dsl {
            external('jenkins_pipeline/test.groovy')
        }
    }
}
