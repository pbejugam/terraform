pipeline {
  environment {
    registry = "registry.cloud.tenable.com"
    registryCredential = 'tenable_registry'
    dockerImage = ''
  }
  agent { 
    label 'tenable_cs'
  }
  stages {
    stage('Checkout from git') {
      steps {
        dir ("${env.RECOMMEND_DIR}"){
          checkout scm: [
            $class: 'GitSCM', userRemoteConfigs: [
              [
                url: 'git@dev-github.albertsons.com:albertsons/platform-app-support.git',
                credentialsId: 'tenable_git',
                changelog: false,
              ]
            ],
            poll: false
          ]
        }
      }
    }

    stage('Build') {
      steps {
         sh 'npm install'
       }
    }

    stage('Test') {
      steps {
        sh 'npm test'
      }
    }

    stage('Building image') {
      steps{
        script {
          dockerImage = docker.build registry + ":$BUILD_NUMBER"
        }
      }
    }

    stage('Deploy Image') {
      steps{
        script {
          docker.withRegistry( '', registryCredential ) {
          dockerImage.push()
          }
        }
      }
    }
    stage('Remove Unused docker image') {
      steps{
        sh "docker rmi $registry:$BUILD_NUMBER"
      }
    }
  }
}

//tersting github HA latest
